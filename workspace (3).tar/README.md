# iprecon — пайплайн разведки RIPE-диапазонов (Python + Redis + PostgreSQL, без Docker)

Конвейер из независимых скриптов:

| Этап | Скрипт | Что делает |
|------|--------|------------|
| 0 | `iprecon/scripts/00_fetch_ripe.py` | Скачивает `https://ftp.ripe.net/pub/stats/ripencc/delegated-ripencc-latest`, парсит и грузит диапазоны в PostgreSQL (`ripe_ranges`). Идемпотентен (UPSERT). |
| 1 | `iprecon/scripts/01_select_and_shard.py` | Отбирает диапазоны по критериям (**страна**, **размер**), режет их на **шарды по 256 адресов**, пишет в `shards` и кладёт задачи в Redis-очередь. |
| 2 | `iprecon/scripts/02_ptr_worker.py` | Воркер: опрашивает **PTR DNS-записи** всех адресов шардов из очереди (asyncio + dnspython, rate-limit). Результаты — в очередь `ptr_results`. Можно запускать несколько экземпляров параллельно. |
| 3 | `iprecon/scripts/03_load_ptr.py` | Вычитывает результаты PTR из Redis и пишет их в БД (`ptr_records`), одновременно ставит пары (hostname, ip) в очередь проверки A-записей. |
| 4 | `iprecon/scripts/04_check_a.py` | Проверяет для каждого найденного хостнейма наличие **прямой A-записи**; помечает `has_a_record` / `points_back` в `a_record_checks` и ставит хосты с A-записью в очередь веб-проверок. |
| 5 | `iprecon/scripts/05_check_web.py` | Проверяет **доступность веб-сервера** (http/https) по хостам с A-записью: статус, Server-заголовок, `<title>`, финальный URL → `web_checks`; доступные — в очередь OWA. |
| 6 | `iprecon/scripts/06_check_owa.py` | Ищет **Outlook Web Access**: пробы `/owa/`, `/owa/auth/logon.aspx`, `/autodiscover/autodiscover.xml`, анализ редиректов, OWA/Exchange-маркеров в заголовках и теле → `owa_checks` (is_owa, confidence, evidence). Плюс **определение версии Exchange**: X-Owa-Version, feOwaVersion в JS, meta msExCcVer, cookie ClientInfo → `exchange_version`, `build_number`, `version_source` (справочник сборок — `iprecon/owa_version.py`). |
| 7 | `iprecon/scripts/07_report.py` | Сводный отчёт по всем этапам + топ OWA-находок. |

Архитектура: PostgreSQL — источник истины и результатов; Redis — надёжные очереди задач
(`ready` + `processing` списки, BLMOVE/RPOPLPUSH, возврат зависших задач через `--reclaim`).
Этапы связаны очередями, каждый скрипт можно перезапускать — запись идемпотентна.

---

## Требования (без Docker)

- Python 3.10+ (проверено на 3.12)
- PostgreSQL 14+ (нужны типы `inet`, `jsonb`)
- Redis 6+ (нужен `BLMOVE`, есть с Redis 6.2)
- Доступ к DNS-резолверу и выход в интернет (RIPE FTP/HTTPS, HTTP/HTTPS до целей)

Установка пакетов (Debian/Ubuntu):

```bash
sudo apt-get update
sudo apt-get install -y postgresql postgresql-client redis-server python3-venv python3-pip
```

## Быстрый старт

```bash
./setup_env.sh            # venv + зависимости + запуск PG/Redis + роль/БД + схема
source .venv/bin/activate
cp .env.example .env      # при необходимости поправьте критерии отбора/подключения
./run_pipeline.sh         # весь пайплайн от начала до отчёта
```

> **Важно:** `run_pipeline.sh` — это **Bash-скрипт**, а не Python. Запускать его
> нужно так: `./run_pipeline.sh` или `bash run_pipeline.sh`.
> Не запускайте его интерпретатором Python (`.venv/bin/python run_pipeline.sh`) —
> это вызовет `SyntaxError: unmatched ')'`, потому что Python не понимает
> bash-конструкции `case ... ;;`.

`setup_env.sh` можно запустить с `--no-apt`, если системные пакеты уже стоят.

### Ручная подготовка (альтернатива setup_env.sh)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

sudo service postgresql start          # или systemctl start postgresql
sudo service redis-server start        # или redis-server --daemonize yes

sudo -u postgres psql -c "CREATE ROLE iprecon LOGIN PASSWORD 'iprecon';"
sudo -u postgres createdb -O iprecon iprecon

cp .env.example .env
python -m iprecon.db_schema            # инициализация схемы
```

## Запуск по этапам

```bash
# 0. скачать RIPE и загрузить в БД (можно --limit 1000 для теста, --file локальный файл)
python -m iprecon.scripts.00_fetch_ripe

# 1. отбор по стране/размеру и шардинг по 256 адресов (критерии — из .env или CLI)
python -m iprecon.scripts.01_select_and_shard --countries DE,NL,FR --prefix-len 24 --max-ranges 10
#     dry-run без записи в БД/Redis:
python -m iprecon.scripts.01_select_and_shard --dry-run

# 2. PTR-обход (запустите несколько терминалов/процессов параллельно)
python -m iprecon.scripts.02_ptr_worker --workers 4 --once --reclaim

# 3. запись PTR-результатов в PostgreSQL
python -m iprecon.scripts.03_load_ptr --once

# 4. проверка A-записей
python -m iprecon.scripts.04_check_a --from-queue          # воркер по очереди
python -m iprecon.scripts.04_check_a --all --limit 5000    # или разовая выборка из БД

# 5. доступность веб-серверов
python -m iprecon.scripts.05_check_web --from-queue

# 6. поиск OWA
python -m iprecon.scripts.06_check_owa --from-queue

# 7. отчёт
python -m iprecon.scripts.07_report [--format csv]
```

### run_pipeline.sh

```bash
./run_pipeline.sh                                   # все этапы
./run_pipeline.sh --limit-ranges 5 --ptr-workers 2  # быстрый тест
SKIP=fetch ./run_pipeline.sh                        # пропустить скачивание RIPE
ONLY=report ./run_pipeline.sh                       # только отчёт
```

## Конфигурация (.env)

| Переменная | Описание |
|---|---|
| `RIPE_URL` | источник delegated-ripencc |
| `TARGET_COUNTRIES` | CC-коды для отбора, напр. `DE,NL,FR` (пусто = все) |
| `MIN_RANGE_SIZE` / `MAX_RANGE_SIZE` | фильтр по размеру диапазона в адресах (`256/256` = точные /24) |
| `MIN_PREFIX_LEN` / `MAX_PREFIX_LEN` | фильтр по длине префикса выровненных CIDR |
| `SHARD_SIZE` | размер шарда, по умолчанию **256** |
| `DATABASE_URL` | `postgresql+psycopg://user:pass@localhost:5432/iprecon` |
| `REDIS_URL` | `redis://localhost:6379/0` |
| `DNS_NAMESERVERS` | свои resolvers через запятую (пусто = системные) |
| `PTR_CONCURRENCY`, `PTR_RATE_LIMIT` | параллельность и rps PTR-опроса |
| `HTTP_CONCURRENCY`, `HTTP_TIMEOUT`, `VERIFY_TLS` | параметры веб-проверок |
| `OWA_PATHS` | пути для OWA-проб |

## Полезные SQL-запросы

```sql
-- где у найденных PTR-хостов есть прямая A-запись:
SELECT hostname, host(expected_ip), array_agg(host(i)) AS a_ips
  FROM a_record_checks, unnest(resolved_ips) i
 WHERE has_a_record GROUP BY 1,2 ORDER BY points_back DESC NULLS LAST;

-- доступные веб-серверы:
SELECT hostname, url, http_status, server_header, title FROM web_checks WHERE reachable;

-- обнаруженный OWA и его версия Exchange:
SELECT hostname, probe_url, confidence, exchange_version, build_number, version_source, evidence
  FROM owa_checks WHERE is_owa ORDER BY confidence;

-- сводка по версиям Exchange:
SELECT COALESCE(exchange_version,'(не определена)') ver, count(DISTINCT hostname) hosts
  FROM owa_checks WHERE is_owa GROUP BY 1 ORDER BY hosts DESC;
```

## Мониторинг очередей Redis

```bash
redis-cli llen iprecon:queue:ptr_shards       # шарды в работе
redis-cli llen iprecon:queue:ptr_results      # PTR-результаты до записи в PG
redis-cli llen iprecon:queue:a_checks
redis-cli llen iprecon:queue:web_checks
redis-cli llen iprecon:queue:owa_checks
```

Если воркер упал mid-flight — задачи остаются в `*:processing`; верните их
запуском с `--reclaim` (или `SimpleQueue.reclaim_stale()`).

## Примечания

- Соблюдайте вежливость к DNS и целевым серверам: крутите `PTR_RATE_LIMIT`, `HTTP_CONCURRENCY`.
- Проверка чужих IP/серверов — только в рамках закона и разрешённого scope.

## Синхронизация кода с GitHub

Все исправления фиксируются коммитами в ветке `master`. Чтобы обновить код на python-хостах:

```bash
cd /opt/iprecon          # или куда вы клонировали репозиторий
git fetch origin
git reset --hard origin/master   # либо git pull, если локальных правок нет
```

Если кнопка Commit в веб-интерфейсе неактивна — это значит, что рабочее дерево чистое: все изменения уже закоммичены локально. Если при этом на github.com последние коммиты не видны, значит локальные коммиты ещё не отправлены (push) в ваш форк/репозиторий — выполните push из интерфейса или `git push origin master` там, где настроен remote с токеном.

## FAQ / типовые ошибки

### 1. `env: 'bash\r': No such file or directory`

Причина: shell-скрипты (`run_pipeline.sh`, `setup_env.sh`) были перенесены на
сервер с Windows (через scp/ftp/блокнот или `git config core.autocrlf true`) —
в файле появились Windows-переводы строк `\r\n` (CRLF), и ядро Linux не может
исполнить shebang `#!/usr/bin/env bash\r`.

Исправление (выполнить в каталоге проекта на сервере):

```bash
# все .sh файлы за один проход:
sed -i 's/\r$//' *.sh
# или, если установлен dos2unix:
dos2unix run_pipeline.sh setup_env.sh
chmod +x run_pipeline.sh setup_env.sh
```

Профилактика: в репозитории добавлен `.gitattributes` (`*.sh text eol=lf`);
при копировании архивом с Windows используйте `unzip` (он сохраняет байты
как есть) или сразу выполняйте `sed -i 's/\r$//' *.sh`. Скрипты теперь сами
проверяют свой файл на CRLF и выводят понятную инструкцию вместо непонятной
ошибки `env`.

### 2. `SyntaxError: unmatched ')'` при запуске через Python

Нельзя запускать bash-скрипт интерпретатором Python
(`python run_pipeline.sh`). Правильно:

```bash
./run_pipeline.sh --limit-ranges 5 --ptr-workers 2
# или
bash run_pipeline.sh --limit-ranges 5 --ptr-workers 2
```

Python-скрипты запускаются отдельно: `.venv/bin/python -m iprecon.scripts...`
(см. «Запуск по этапам»).

### 3. `--- Logging error --- KeyError: 'host'` в логах

Причина: формат логов содержит поле `[%(host)s]`, но оно не добавлялось в
записи, пришедшие от дочерних/сторонних логгеров (фильтр висел только на
логгере, а не на обработчиках). Исправлено: фильтр `_HostFieldFilter`
навешивается на каждый handler. Если вы обновили код — просто синхронизируйте
`iprecon/logsetup.py` на всех python-хостах. Временный обход без обновления:
`export LOG_CONSOLE=false LOG_TO_FILE=false` (логи в stderr/файл не пишутся).

### 4. `redis.exceptions.AuthenticationError: HELLO must be called with the client already authenticated`

Redis на вашем сервере требует пароль, а в `.env` он не указан (или указан
некорректно). Исправьте `REDIS_URL` в `.env` на каждом python-хосте:

```ini
# Redis с паролем (requirepass) — двоеточие перед @ обязательно (пустое имя пользователя):
REDIS_URL=redis://:ВАШ_ПАРОЛЬ@redis.example.com:6379/0
# ACL-пользователь (Redis >= 6):
REDIS_URL=redis://myuser:mypass@redis.example.com:6379/0
# TLS:
REDIS_URL=rediss://:mypassword@redis.example.com:6379/0
```

Дополнительно:
- если Redis старый (< 6.0) и не понимает протокол RESP3 — добавьте
  `REDIS_PROTOCOL=2`;
- скрипты теперь при неудачном handshake автоматически пробуют вариант
  RESP2 + AUTH, а если и это не удалось — выводят понятную инструкцию;
- проверьте на redis-хосте в `redis.conf`: `bind 0.0.0.0` (или нужный IP),
  `protected-mode no` (если без пароля) или `requirepass <пароль>`,
  и доступность порта 6379 firewall'ом;
- быстрая проверка с python-хоста:
  `redis-cli -h <IP> -a '<пароль>' ping` → должен ответить `PONG`.

### 5. `TypeError: StreamCommands.xadd() got an unexpected keyword argument 'approx'`

Причина: несовместимость версий библиотеки `redis-py`. В старых версиях
(< 5.0) параметр приблизительного MAXLEN в `XADD` назывался `approx`, начиная
с 5.0 — `approximate`. Код исправлен: `_xadd_kwargs()` в `iprecon/redisq_stream.py`
сам определяет имя параметра по сигнатуре установленного клиента, поэтому
работает с redis-py 5.x–8.x.

Что сделать на серверах (обновите код ИЛИ просто переставьте библиотеку):

```bash
/opt/.venv/bin/pip install -U "redis>=5"   # рекомендуемый путь
# и синхронизируйте iprecon/redisq_stream.py на все python-хосты
```

Проверить версию: `/opt/.venv/bin/python -c "import redis; print(redis.__version__)"`

### 6. Ошибки логирования повторяются после обновления кода — проверьте PYTHONPATH

Если скрипты запускаются как `python /opt/iprecon/scripts/...`, а пакет
`iprecon` также установлен отдельно (например, в `/opt/site-packages` или через
`pip install ./iprecon`), интерпретатор может импортировать **старую копию**
модуля, и фиксы «не применяются». Диагностика:

```bash
/opt/.venv/bin/python -c "import iprecon.logsetup as m; print(m.__file__)"
```

Путь должен указывать на актуальный рабочий каталог проекта (`/opt/iprecon/...`).
Если нет — удалите старую копию из site-packages или запускайте из корня проекта
(`run_pipeline.sh` сам выставляет `PYTHONPATH=/opt`).
