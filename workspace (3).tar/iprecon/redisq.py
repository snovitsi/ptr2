"""Обёртка над Redis: надёжные очереди (BLMOVE / RPOPLPUSH) с видимостью задач.

Схема очередей:
  <queue>          — список "готовых к работе" задач
  <queue>:processing — список задач, взятых воркерами в работу

Возврат задачи в очередь ("ack"=False) нужен при падении воркера.
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Iterator

import redis

log = logging.getLogger("iprecon.redisq")


class SimpleQueue:
    """Упрощённая надёжная очередь: задачи хранятся как JSON-строки.

    pop()  -> BLMOVE right->processing left
    ack(payload_raw) -> LREM processing
    """

    def __init__(self, r: redis.Redis, name: str):
        self.r = r
        self.name = name
        self.processing = f"{name}:processing"

    def push(self, payload: dict) -> None:
        self.r.rpush(self.name, json.dumps(payload, ensure_ascii=False))

    def push_batch(self, payloads: list[dict]) -> None:
        if not payloads:
            return
        pipe = self.r.pipeline(transaction=False)
        for p in payloads:
            pipe.rpush(self.name, json.dumps(p, ensure_ascii=False))
        pipe.execute()

    def pop(self, timeout: int = 3) -> tuple[str, dict] | None:
        raw = self.r.blmove(
            self.name, self.processing, timeout=timeout, src="RIGHT", dest="LEFT"
        )
        if raw is None:
            return None
        return raw, json.loads(raw)

    def ack(self, raw: str) -> None:
        self.r.lrem(self.processing, 1, raw)

    def done(self, raw: str) -> None:
        """Отметить обработку завершённой без возврата в ready (то же, что ack)."""
        self.r.lrem(self.processing, 1, raw)

    def requeue(self, raw: str) -> None:
        self.r.lrem(self.processing, 1, raw)
        self.r.rpush(self.name, raw)

    def depth(self) -> int:
        return self.r.llen(self.name)

    def processing_depth(self) -> int:
        return self.r.llen(self.processing)

    def reclaim_stale(self, max_idle_sec: int = 0) -> int:
        """Возврат всех зависших задач из processing в ready (для перезапуска)."""
        n = 0
        while True:
            raw = self.r.rpoplpush(self.processing, self.name)
            if raw is None:
                break
            n += 1
        return n

    def clear(self) -> None:
        self.r.delete(self.name, self.processing)


def get_redis(url: str | None = None) -> redis.Redis:
    from .config import get_config

    url = url or get_config().redis_url

    parsed = redis.connection.parse_url(url)
    host = parsed.get("host", "localhost")
    port = int(parsed.get("port", 6379))
    db = int(parsed.get("db", 0) or 0)
    username = parsed.get("username") or None
    password = parsed.get("password") or None
    use_ssl = bool(parsed.get("ssl") or str(url).startswith("rediss://"))

    base_kwargs: dict[str, Any] = dict(
        decode_responses=True,
        # для удалённого Redis: не «зависать» навечно при обрыве сети
        socket_connect_timeout=float(os.environ.get("REDIS_CONNECT_TIMEOUT", "5")),
        socket_timeout=float(os.environ.get("REDIS_SOCKET_TIMEOUT", "10")),
        socket_keepalive=True,
        health_check_interval=int(os.environ.get("REDIS_HEALTH_CHECK_INTERVAL", "30")),
        retry_on_timeout=True,
    )
    protocol_env = os.environ.get("REDIS_PROTOCOL", "").strip()
    if protocol_env in ("2", "3"):
        base_kwargs["protocol"] = int(protocol_env)

    def _attempt(label: str, **overrides) -> tuple[bool, redis.Redis | Exception]:
        kw = {**base_kwargs, **overrides}
        try:
            r = redis.Redis(host=host, port=port, db=db, ssl=use_ssl, **kw)
            r.ping()
            return True, r
        except Exception as e:  # noqa: BLE001
            log.debug("Redis attempt %s failed: %s", label, e)
            return False, e

    errors: list[str] = []

    # 1) как задано в URL (учитывая REDIS_PROTOCOL)
    ok, res = _attempt("default", username=username, password=password)
    if ok:
        return res  # type: ignore[return-value]
    errors.append(f"как в URL ({username or 'user-не-задан'}): {res}")

    err_text = " ".join(str(e) for e in errors).lower()
    auth_related = any(k in err_text for k in
                       ("auth", "hello", "wrongpass", "permission", "protocol"))

    # 2) если пароль задан, но handshake не прошёл — корректируем способ AUTH:
    #    только пароль (legacy requirepass) либо ACL user 'default' (Redis>=6)
    if password and auth_related:
        for label, u in (("только пароль (legacy requirepass)", None),
                         ("ACL user 'default'", "default")):
            if u == username:
                continue
            ok, res = _attempt(label, username=u, password=password)
            if ok:
                log.warning("Redis подключился после корректировки AUTH (%s). "
                            "Рекомендуемый формат REDIS_URL: redis://:%s@%s:%d/%d",
                            label, password, host, port, db)
                return res  # type: ignore[return-value]
            errors.append(f"{label}: {res}")

    # 3) протокол RESP3 не поддержан сервером/прослойкой (HELLO unknown) —
    #    пробуем принудительный RESP2 (для старых Redis <6.0)
    if "unknown command" in err_text and "hello" in err_text and \
            base_kwargs.get("protocol") != 2:
        ok, res = _attempt("RESP2", username=username, password=password, protocol=2)
        if ok:
            log.warning("Redis не понимает HELLO/RESP3 — подключение через RESP2. "
                        "Добавьте в .env: REDIS_PROTOCOL=2")
            return res  # type: ignore[return-value]
        errors.append(f"RESP2: {res}")

    first_line = (errors[0] if errors else "нет попыток").splitlines()[0]
    raise redis.exceptions.ConnectionError(
        f"Не удалось подключиться к Redis {host}:{port}/{db}.\n"
        + "\n".join(f"  - {e.splitlines()[0] if isinstance(e, str) else str(e).splitlines()[0]}"
                    for e in errors)
        + "\nЧастые причины и решения:\n"
        "  1) Сервер требует пароль. Пропишите его в .env (двоеточие перед @ обязательно):\n"
        "       REDIS_URL=redis://:<ПАРОЛЬ>@хост:6379/0\n"
        "     ACL-пользователь (Redis>=6): redis://user:pass@хост:6379/0\n"
        "  2) Старый Redis (<6) не понимает HELLO/RESP3 — добавьте: REDIS_PROTOCOL=2\n"
        "  3) На redis-хосте в redis.conf: bind (нужный IP или 0.0.0.0),\n"
        "     protected-mode no (если без пароля) либо requirepass <пароль>; порт открыт firewall'ом.\n"
        f"  4) Проверка вручную: redis-cli -h {host} -p {port} -a '<пароль>' ping  -> PONG\n"
        f"  Первая ошибка: {first_line}"
    )


def heartbeat(r: redis.Redis, key: str, ttl: int = 60) -> None:
    r.set(key, str(time.time()), ex=ttl)


def is_alive(r: redis.Redis, key: str) -> bool:
    return bool(r.exists(key))
